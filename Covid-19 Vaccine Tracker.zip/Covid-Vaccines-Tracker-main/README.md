![GitHubHeader](https://user-images.githubusercontent.com/46765573/119278437-96845980-bc25-11eb-89ab-abf67a795254.png)
  # Covidvaccinetrack.com

  <p align="center">
https://covidvaccinetrack.com/
      was created to keep people informed about the administered doses of the covid vaccine <br> around the world. There are no ads, and there never will be. We          have no intention of taking advantage<br> of a global pandemic that has killed millions of people.<br><br>
      ANYONE is welcome here, I will accept any kind of contribution, whether you are a novice developer or with experience.    <br />
  </p>

### Built With
* [Bootstrap](https://getbootstrap.com)
* [JQuery](https://jquery.com)
